## onetrace instrumentation

When asked to add or change onetrace instrumentation, read and follow the recipe:
https://oneproof.dev/onetrace/agents/instrument.md (fetch the raw file; local copy:
docs/onetrace/instrument.md). Reference links: https://oneproof.dev/onetrace/llms.txt.
Add recording only. Leave the trust fields unset and ask. Never put a secret in a
decorator or config. Report test, verify and diff results at the end.
