## onetrace instrumentation

This project records its pipeline runs with onetrace.

- To add or change instrumentation, first read the recipe in full:
  https://oneproof.dev/onetrace/agents/instrument.md
  (raw file, not a summary; local copy: docs/onetrace/instrument.md if present).
- Reference links: https://oneproof.dev/onetrace/llms.txt
- Add recording only; never change what the pipeline computes or returns.
- Leave trust=, output_trust=, rederivable= and note= unset, and ask the human.
- Never put a key, token or password in a decorator or a config value.
- After a change: run the tests, `onetrace-verify --require-artifacts runs/<run_id>`, and
  `onetrace diff` against a previous run; report the results.
