# onetrace agent kit

Your coding agent does the instrumenting, not you. This kit is how you hand it the job.
Every file in it says the same thing: read the official recipe
(https://oneproof.dev/onetrace/agents/instrument.md), follow it, ask you where it says to ask,
and report back.

## The quickest way, in any agent

Open your project in the agent and paste the contents of `PROMPT.txt` as your message.
That's all. The other files make the same request reusable inside a particular tool.

## Per tool

Copy the file for your tool into the root of your project, keeping its folder.
File locations are those each tool documents; if yours has moved, paste `PROMPT.txt` instead.

| Tool | Copy | Then |
|---|---|---|
| Claude Code | `.claude/commands/onetrace-instrument.md` | Type `/onetrace-instrument` |
| Cursor | `.cursor/rules/onetrace-instrument.mdc` | In Agent chat: "follow @onetrace-instrument" |
| GitHub Copilot (VS Code, agent mode) | `.github/prompts/onetrace-instrument.prompt.md` | Type `/onetrace-instrument` in Copilot Chat |
| Windsurf | `.windsurf/rules/onetrace-instrument.md` | In Cascade: "@onetrace-instrument" |
| Cline | `.clinerules/onetrace-instrument.md` | Ask Cline to "instrument this repo with onetrace" |
| Codex, Jules, Amp and other agents that read AGENTS.md | `AGENTS.md` (merge into yours) | Ask the agent to "instrument this repo with onetrace" |
| Any other agent | `PROMPT.txt` | Paste it as your message |

`AGENTS.md` and `CLAUDE.md` are also worth keeping after the first pass: they tell any later
agent edit to keep the instrumentation consistent. If you already have these files, add the
section to them rather than replacing them.

## See the runs afterwards

Once onetrace is in your code, each run of your program writes a folder under `runs/`.
In the same environment you run your program in:

    pip install onetrace-console
    onetrace-console runs --open

Add `--compare <first> <second>` (two run folder names) to compare two runs, and `--port 8091`
if port 8080 is taken. The console reads the folder when it starts: restart it after new runs.
Step-by-step help: https://oneproof.dev/get-started.html

## If your agent can't fetch web pages

Download https://oneproof.dev/onetrace/agents/instrument.md and save it in your project as
`docs/onetrace/instrument.md`. Every file in this kit tells the agent to read it from there.

## What you'll be asked

The recipe has the agent stop and ask you about the things only you know: what one run of
your pipeline is, how to treat an external index, the trust fields it leaves unset on
purpose, and whether to sign records. Expect a short list of questions and a report with
test, verify and diff results at the end.

onetrace: https://oneproof.dev · Issues: https://github.com/shamiksaharcciit-oss/onetrace-issues
