Instrument this repository's Python pipeline with onetrace.

1. Read the recipe in full before you change anything:
   https://oneproof.dev/onetrace/agents/instrument.md
   Fetch the raw file and work from it, not from a summary.
   If you can't fetch URLs, read docs/onetrace/instrument.md in this repository instead,
   and tell me if that file is missing.
2. For reference links (decorators, errors and fixes, verdicts), use
   https://oneproof.dev/onetrace/llms.txt
3. Follow the recipe's sections 0 to 7 in order. Add recording only: the pipeline must
   produce exactly the same results as before.
4. Stop and ask me wherever the recipe says to ask: what one run is, an external index,
   the trust fields it tells you to leave unset, signing, and anything you're unsure of.
5. Never put a key, token or password in a decorator, a config value or a commit.
6. Finish with the report the recipe's section 7 describes: what you decorated (file and
   line), what you recorded, the open questions, and the test, verify and diff results.
